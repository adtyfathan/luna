<?php

use Illuminate\Support\Facades\Route;
use App\Livewire\Beranda;
use App\Livewire\Perusahaan\CreatePerusahaan;
use App\Livewire\Perusahaan\EditPerusahaan;
use App\Livewire\Perusahaan\PerusahaanIndex;
use App\Livewire\Edukasi;
use App\Livewire\Materi;
// Pengalaman
use App\Livewire\Pengalaman\Create as CreatePengalaman;
use App\Livewire\Pengalaman\Edit as EditPengalaman;

// Pendidikan
use App\Livewire\Pendidikan\Create as CreatePendidikan;
use App\Livewire\Pendidikan\Edit as EditPendidikan;

// Post
use App\Livewire\Post\Create as CreatePost;
use App\Livewire\Post\Edit as EditPost;
use App\Livewire\Post\Show as ShowPost;

// Produk
use App\Livewire\Perusahaan\Produk\Create as CreateProduk;
use App\Livewire\Perusahaan\Produk\Edit as EditProduk;
use App\Livewire\Perusahaan\Produk\Show as ShowProduk;

use App\Livewire\Pengguna;

use App\Livewire\Koneksi;

use App\Livewire\Perusahaan\Post\Create as CreatePerusahaanPost;
use App\Livewire\Perusahaan\Post\Edit as EditPerusahaanPost;
use App\Livewire\Perusahaan\Post\Show as ShowPerusahaanPost;

Route::get('/', Beranda::class)->name('beranda');
Route::get('/edukasi', Edukasi::class)->name('edukasi');
Route::get('/edukasi/{materiId}', Materi::class)->name('materi');

Route::middleware(['auth'])->group(function(){
    Route::view('profile', 'profile')
        ->middleware(['auth'])
        ->name('profile');

    Route::prefix('/pengalaman')->name('pengalaman')->group(function () {
        Route::get('/create', CreatePengalaman::class)->name('.create');
        Route::get('/edit/{pengalamanId}', EditPengalaman::class)->name('.edit');
    });

    Route::prefix('/pendidikan')->name('pendidikan')->group(function () {
        Route::get('/create', CreatePendidikan::class)->name('.create');
        Route::get('/edit/{pendidikanId}', EditPendidikan::class)->name('.edit');
    });

    Route::prefix('/post')->name('post')->group(function () {
        Route::get('/create', CreatePost::class)->name('.create');
        Route::get('/edit/{postId}', EditPost::class)->name('.edit');
        Route::get('/show/{postId}', ShowPost::class)->name('.show');
    });

    Route::get('/pengguna/{userId}', Pengguna::class)->name('pengguna');

    Route::get('/koneksi', Koneksi::class)->name('koneksi');
    Route::prefix('/perusahaan')->name('perusahaan')->group(function () {
        Route::get('/create', CreatePerusahaan::class)->name('.create');
        Route::get('/edit/{perusahaanId}', EditPerusahaan::class)->name('.edit');
        Route::get('/index/{perusahaanId}', PerusahaanIndex::class)->name('.index');

        Route::prefix('/post')->name('.post')->group(function () {
            Route::get('/create/{perusahaanId}', CreatePerusahaanPost::class)->name('.create');
            Route::get('/edit/{postId}', EditPerusahaanPost::class)->name('.edit');
            Route::get('/show/{postId}', ShowPerusahaanPost::class)->name('.show');
        });

        Route::prefix('/produk')->name('.produk')->group(function () {
            Route::get('/create/{perusahaanId}', CreateProduk::class)->name('.create');
            Route::get('/edit/{produkId}', EditProduk::class)->name('.edit');
            Route::get('/show/{produkId}', ShowProduk::class)->name('.show');
        });
    });
});

require __DIR__.'/auth.php';