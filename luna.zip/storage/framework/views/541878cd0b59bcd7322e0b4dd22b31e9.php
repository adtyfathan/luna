<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />
        

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    </head>
    <body class="font-sans antialiased">
        <div class="min-h-screen bg-gray-100">
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('layout.navigation', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-566537104-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

            <!-- Page Heading -->
            <?php if(isset($header)): ?>
                <header class="bg-white shadow">
                    <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
                        <?php echo e($header); ?>

                    </div>
                </header>
            <?php endif; ?>

            <!-- Page Content -->
            <main>
                <?php echo e($slot); ?>

                <footer class="bg-gray-900 text-gray-300 py-10 mt-10">
                    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                
                            <!-- Logo & About -->
                            <div>
                                <div class="flex items-center gap-2">
                                    <?php if (isset($component)) { $__componentOriginal8892e718f3d0d7a916180885c6f012e7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8892e718f3d0d7a916180885c6f012e7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.application-logo','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('application-logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8892e718f3d0d7a916180885c6f012e7)): ?>
<?php $attributes = $__attributesOriginal8892e718f3d0d7a916180885c6f012e7; ?>
<?php unset($__attributesOriginal8892e718f3d0d7a916180885c6f012e7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8892e718f3d0d7a916180885c6f012e7)): ?>
<?php $component = $__componentOriginal8892e718f3d0d7a916180885c6f012e7; ?>
<?php unset($__componentOriginal8892e718f3d0d7a916180885c6f012e7); ?>
<?php endif; ?>
                                    <h2 class="text-2xl font-bold text-white">Luna</h2>
                                </div>
                                
                                <p class="mt-3 text-sm leading-6">
                                    Lapak UMKM Indonesia
                                </p>
                            </div>
                
                            <!-- Quick Links -->
                            <div>
                                <h3 class="text-lg font-semibold text-white mb-3">Quick Links</h3>
                                <ul class="space-y-2">
                                    <li><a href="" class="hover:text-white transition">Home</a></li>
                                    <li><a href="" class="hover:text-white transition">About</a></li>
                                    <li><a href="" class="hover:text-white transition">Services</a></li>
                                    <li><a href="" class="hover:text-white transition">Contact</a></li>
                                </ul>
                            </div>
                
                            <!-- Resources -->
                            <div>
                                <h3 class="text-lg font-semibold text-white mb-3">Resources</h3>
                                <ul class="space-y-2">
                                    <li><a href="" class="hover:text-white transition">Blog</a></li>
                                    <li><a href="" class="hover:text-white transition">Help Center</a></li>
                                    <li><a href="" class="hover:text-white transition">Terms of Service</a></li>
                                    <li><a href="" class="hover:text-white transition">Privacy Policy</a></li>
                                </ul>
                            </div>
                        </div>
                
                        <!-- Bottom -->
                        <div class="mt-10 border-t border-gray-700 pt-6 text-center text-sm">
                            © <?php echo e(date('Y')); ?> Luna. All rights reserved.
                        </div>
                    </div>
                </footer>

            </main>
        </div>
    </body>
</html>
<?php /**PATH D:\laragon\www\luna\resources\views\layouts\app.blade.php ENDPATH**/ ?>