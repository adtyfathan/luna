<div class="max-w-6xl mx-auto p-4 space-y-6">
    <div class="grid grid-cols-1 lg:grid-cols-4 gap-6">

        <?php if($user): ?>
            
            <div class="space-y-6">

                
                <div class="bg-white rounded-xl shadow-lg border border-blue-100 p-6 bg-gradient-to-br from-white to-blue-50/50">
                    <div class="flex items-center gap-4">
                        <?php if($user->foto_profil): ?>
                            <img class="h-10 w-10 object-cover rounded-full shadow-sm"
                                src="<?php echo e(Storage::url($user->foto_profil)); ?>" alt="<?php echo e($user->name); ?>'s avatar">
                        <?php else: ?>
                            <div
                                class="h-10 w-10 rounded-full bg-gradient-to-br from-white to-blue-100 flex items-center justify-center shadow-sm">
                                <img class="h-10 w-10 object-cover rounded-full opacity-90"
                                    src="<?php echo e(asset('images/default-avatar.png')); ?>" alt="<?php echo e($user->name); ?>'s avatar">
                            </div>
                        <?php endif; ?>

                        <div>
                            <a href="<?php echo e(route('pengguna', $user->id)); ?>" wire:navigate
                                class="font-bold text-gray-900"><?php echo e($user->name); ?></a>
                            <p class="text-gray-500 text-sm"><?php echo e($user->headline); ?></p>
                        </div>
                    </div>

                    <?php if($user->provinsi || $user->kota): ?>
                        <div class="flex items-center text-gray-500 my-4">
                            <svg class="h-4 w-4 mr-2 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z">
                                </path>
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M15 11a3 3 0 11-6 0 3 3 0 016 0z">
                                </path>
                            </svg>
                            <span class="text-sm">
                                <?php if($user->kota && $user->provinsi): ?>
                                    <?php echo e($user->kota->nama_kota); ?>, <?php echo e($user->provinsi->nama_provinsi); ?>

                                <?php elseif($user->kota): ?>
                                    <?php echo e($user->kota->nama_kota); ?>

                                <?php elseif($user->provinsi): ?>
                                    <?php echo e($user->provinsi->nama_provinsi); ?>

                                <?php endif; ?>
                            </span>
                        </div>
                    <?php endif; ?>

                    <?php
                        $latestPengalaman = auth()->user()->pengalaman()->latest()->first();
                        // dump($latestPengalaman);
                    ?>

                    <?php if($latestPengalaman): ?>

                        <div class="flex items-center text-gray-500 my-4">
                            <img class="h-8 w-8 mr-2 object-cover rounded-full opacity-90" src="<?php echo e(asset('images/google.png')); ?>"
                                alt="company logo">
                            <span class="text-sm">
                                <?php echo e($latestPengalaman->nama_perusahaan); ?>

                            </span>
                        </div>
                    <?php endif; ?>

                    <?php
                        $latestPendidikan = auth()->user()->pendidikan()->latest()->first();
                        // dump($latestPendidikan);
                    ?>

                    <?php if($latestPendidikan): ?>
                        <div class="flex items-center text-gray-500 my-4">
                            <img class="h-8 w-8 mr-2 object-cover rounded-full opacity-90" src="<?php echo e(asset('images/unsoed.png')); ?>"
                                alt="pedidikan logo">
                            <span class="text-sm">
                                <?php echo e($latestPendidikan->nama_institusi); ?>

                            </span>
                        </div>
                    <?php endif; ?>

                    <div class="space-y-3 my-3">
                        <a href="<?php echo e(route('pengguna', auth()->user()->id)); ?>" wire:navigate
                            class="flex items-center gap-2 text-sm text-gray-700 hover:text-black transition duration-100 bg-blue-50 p-3 hover:bg-blue-100 rounded-lg">
                            <svg class="h-5 w-5 text-gray-700 hover:text-black" fill="none" stroke="currentColor"
                                viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                            </svg>
                            Profil saya
                        </a>
                    </div>

                    <div class="space-y-3">
                        <a href="<?php echo e(route('profile')); ?>" wire:navigate
                            class="flex items-center gap-2 text-sm text-gray-700 hover:text-black transition duration-100 bg-blue-50 p-3 hover:bg-blue-100 rounded-lg">
                            <svg class="h-5 w-5 text-gray-700 hover:text-black" fill="none" stroke="currentColor"
                                viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M3 7h3l2-3h8l2 3h3v13H3V7z" />
                                <circle cx="12" cy="13" r="4" stroke-width="2" stroke="currentColor" fill="none" />
                            </svg>

                            Kelola postingan
                        </a>
                    </div>
                </div>

                <?php if($perusahaanUser): ?>
                    
                    <div class="bg-white rounded-xl shadow-lg border border-blue-100 p-6 bg-gradient-to-br from-white to-blue-50/50">
                        <h3 class="font-bold text-gray-900 mb-4 flex items-center">
                            <div
                                class="h-6 w-6 bg-gradient-to-r from-blue-500 to-blue-600 rounded-md flex items-center justify-center mr-2">
                                <svg class="h-4 w-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M4 21V9a1 1 0 011-1h3V4a1 1 0 011-1h6a1 1 0 011 1v4h3a1 1 0 011 1v12" />
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M4 21h16M8 13h.01M8 17h.01M12 13h.01M12 17h.01M16 13h.01M16 17h.01" />
                                </svg>

                            </div>
                            UMKM Saya
                        </h3>

                        <?php $__empty_1 = true; $__currentLoopData = $perusahaanUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perusahaan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="space-y-3 my-3">
                                <a href="<?php echo e(route('perusahaan.index', $perusahaan->id)); ?>" wire:navigate
                                    class="flex items-center gap-2 text-sm text-gray-700 hover:text-black transition duration-100 bg-blue-50 p-3 hover:bg-blue-100 rounded-lg">
                                    <img src="<?php echo e($perusahaan->logo ? asset('storage/' . $perusahaan->logo) : asset('images/default-company.png')); ?>"
                                        alt="Company Logo" class="w-8 h-8 rounded-full object-cover ">

                                    <?php echo e($perusahaan->nama_perusahaan); ?>

                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-gray-700 leading-relaxed text-sm">Belum ada UMKM</p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <div class="lg:col-span-3 space-y-6">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($post->author_type === 'App\Models\User' || $post->author_type === 'App\Models\Perusahaan'): ?>
                    <!-- Post Card -->
                    <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-shadow">
                        <!-- Author Info -->
                        <div class="flex items-center gap-4 p-4 cursor-pointer"
                            wire:click="redirectToPost(<?php echo e($post->id); ?>, '<?php echo e($post->author_type); ?>')">
                            <?php
        $avatar = $post->author_type === 'App\\Models\\User'
            ? ($post->author->foto_profil ? Storage::url($post->author->foto_profil) : asset('images/default-avatar.png'))
            : ($post->author->logo ? Storage::url($post->author->logo) : asset('images/default-company.png'));
                            ?>
                            <img src="<?php echo e($avatar); ?>" class="h-14 w-14 object-cover rounded-full border border-gray-300">

                            <div>
                                <h2 class="text-gray-900 font-semibold text-sm sm:text-base hover:underline">
                                    <?php if($post->author_type === 'App\\Models\\User'): ?>
                                        <a href="<?php echo e(route('pengguna', $post->author->id)); ?>" wire:navigate><?php echo e($post->author->name); ?></a>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('perusahaan.index', $post->author->id)); ?>"
                                            wire:navigate><?php echo e($post->author->nama_perusahaan); ?></a>
                                    <?php endif; ?>
                                </h2>
                                <p class="text-gray-500 text-xs sm:text-sm">
                                    <?php echo e($post->author->headline ?? ''); ?>

                                </p>
                                <span class="text-gray-400 text-xs"><?php echo e($post->created_at->diffForHumans()); ?></span>
                            </div>
                        </div>

                        <!-- Post Content -->
                        <div class="px-4 pb-4">
                            <p class="text-gray-800 text-sm sm:text-base mb-3 whitespace-pre-line">
                                <?php echo e($post->konten); ?>

                            </p>

                            <!-- Post Images -->
                            <?php if($post->gambarPost->count() > 0): ?>
                                <?php if($post->gambarPost->count() === 1): ?>
                                    <div class="rounded-lg overflow-hidden">
                                        <img src="<?php echo e(asset('storage/' . $post->gambarPost->first()->url)); ?>"
                                            class="w-full max-h-[500px] object-cover">
                                    </div>
                                <?php else: ?>
                                    <div class="grid grid-cols-2 gap-1 rounded-lg overflow-hidden">
                                        <?php $__currentLoopData = $post->gambarPost->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="relative">
                                                <img src="<?php echo e(asset('storage/' . $image->url)); ?>" class="w-full h-48 object-cover">
                                                <?php if($loop->last && $post->gambarPost->count() > 4): ?>
                                                    <div class="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
                                                        <span class="text-white font-semibold text-lg">+<?php echo e($post->gambarPost->count() - 3); ?></span>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>

                        <!-- Actions -->
                        <div class="border-t border-gray-100 flex justify-around text-sm text-gray-500">
                            <!-- Like -->
                            <button wire:click="toggleLike(<?php echo e($post->id); ?>)"
                                class="flex items-center gap-2 py-3 px-4 hover:bg-gray-50 w-full justify-center">
                                <svg class="w-5 h-5 <?php echo e($post->like->where('user_id', Auth::id())->count() ? 'text-red-500' : 'text-gray-400'); ?>"
                                    fill="currentColor" viewBox="0 0 20 20">
                                    <path d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 
                                                            115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" />
                                </svg>
                                <span><?php echo e($post->like->count()); ?> Suka</span>
                            </button>

                            <!-- Comment -->
                            <div class="flex items-center gap-2 py-3 px-4 hover:bg-gray-50 w-full justify-center cursor-pointer">
                                <svg class="w-5 h-5 text-blue-500" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M18 10c0 3.866-3.582 7-8 7a8.841 8.841 0 
                                                                  01-4.083-.98L2 17l1.338-3.123C2.493 12.767 
                                                                  2 11.434 2 10c0-3.866 3.582-7 
                                                                  8-7s8 3.134 8 7zM7 9H5v2h2V9zm8 
                                                                  0h-2v2h2V9zM9 9h2v2H9V9z" clip-rule="evenodd"></path>
                                </svg>
                                <span><?php echo e($post->komentar->count()); ?> Komentar</span>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>
</div><?php /**PATH D:\laragon\www\luna\resources\views\livewire\beranda.blade.php ENDPATH**/ ?>