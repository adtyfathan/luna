<?php

use Illuminate\Support\Facades\Auth;
use Livewire\Volt\Component;
use Illuminate\Support\Facades\Storage;
use App\Models\Pendidikan;

?>

<section>
    <header>
        <h2 class="text-lg font-medium text-gray-900">
            <?php echo e(__('Riwayat Pendidikan')); ?>

        </h2>
    
        <p class="mt-1 text-sm text-gray-600">
            <?php echo e(__('Daftar riwayat pendidikan anda.')); ?>

        </p>
    </header>

    <div class="space-y-6 mt-6">

        <div>
            <a href="<?php echo e(route('pendidikan.create')); ?>" class="bg-blue-500 text-white py-2 px-6 text-sm rounded-lg font-semibold" wire:navigate>Tambah Pendidikan</a>
        </div>

        <?php $__empty_1 = true; $__currentLoopData = $pendidikans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pendidikan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="my-2 p-4 border-b hover:shadow-md rounded-md transition duration-200">
                <div class="flex flex-col sm:flex-row sm:items-start sm:justify-between">
                    <!-- Main Content -->
                    <div class="flex-1">
                        <div class="flex items-start space-x-4">
                            <!-- Pendidikan Logo -->
                            <div class="flex-shrink-0 mr-4">
                                <?php if($pendidikan->institusiPendidikan && $pendidikan->institusiPendidikan->logo): ?>
                                    <img class="w-12 h-12 rounded-lg object-cover border border-gray-200" 
                                            src="<?php echo e(Storage::url($pendidikan->institusiPendidikan->logo)); ?>" 
                                            alt="<?php echo e($pendidikan->institusiPendidikan->nama_institusi ?? $pendidikan->nama_institusi); ?>">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('images/default-pendidikan.png')); ?>" class="w-12 h-12 rounded-lg flex items-center justify-center shadow-md bg-blue-100" alt="default pendidikan image">         
                                <?php endif; ?>
                            </div>

                            <!-- Pendidikan Details -->
                            <div class="flex-1 min-w-0">
                                <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-2">
                                    <h3 class="text-xl font-semibold text-gray-900 truncate">
                                        <?php if($pendidikan->institusiPendidikan): ?>
                                            <?php echo e($pendidikan->institusiPendidikan->nama_institusi); ?>

                                        <?php else: ?>
                                            <?php echo e($pendidikan->nama_institusi); ?>

                                        <?php endif; ?>
                                    </h3>
                                    <div class="mt-2 sm:mt-0 sm:ml-4 flex justify-center items-center gap-4">
                                        <?php if($pendidikan->tingkat): ?>
                                            <span
                                                class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium <?php echo e($this->getTingkatBadgeColor($pendidikan->tingkat)); ?>">
                                                <?php echo e($pendidikan->tingkat); ?>

                                            </span>
                                        <?php endif; ?>

                                        
                                        <a href="<?php echo e(route('pendidikan.edit', $pendidikan->id)); ?>"
                                            class="inline-flex items-center justify-center rounded-lg transition-colors duration-200"
                                            wire:navigate>
                                            <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                                                <path
                                                    d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z" />
                                            </svg>
                                        </a>

                                        
                                        <button wire:click="delete(<?php echo e($pendidikan->id); ?>)" class="inline-flex items-center justify-center rounded-lg transition-colors duration-200"
                                            onclick="return confirm('Anda yakin menghapus pendidikan ini?')">
                                            <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                                                <path
                                                    d="M9 3V4H4V6H5V19C5 20.1 5.9 21 7 21H17C18.1 21 19 20.1 19 19V6H20V4H15V3H9ZM7 6H17V19H7V6ZM9 8V17H11V8H9ZM13 8V17H15V8H13Z" />
                                            </svg>
                                        </button>
                                    </div>
                                </div>

                                <?php if($pendidikan->jurusan): ?>
                                    <div class="flex items-center text-gray-600 mb-2">
                                        <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4">
                                            </path>
                                        </svg>
                                        <span class="text-sm font-medium">
                                            <?php echo e($pendidikan->jurusan); ?>

                                        </span>
                                    </div>
                                <?php endif; ?>

                                <div class="flex flex-col sm:flex-row sm:items-center text-gray-500 text-sm space-y-1 sm:space-y-0 sm:space-x-4 mb-2">
                                    <div class="flex items-center">
                                        <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3a1 1 0 011-1h6a1 1 0 011 1v4M8 7H3a1 1 0 00-1 1v10a1 1 0 001 1h18a1 1 0 001-1V8a1 1 0 00-1-1h-5M8 7v13M16 7v13"></path>
                                        </svg>
                                        <?php echo e($this->formatDate($pendidikan->tanggal_mulai)); ?> - <?php echo e($pendidikan->tanggal_selesai ? $this->formatDate($pendidikan->tanggal_selesai) : 'Sekarang'); ?>

                                    </div>
                                    <?php if($pendidikan->tanggal_mulai && $pendidikan->tanggal_selesai): ?>
                                        <div class="flex items-center">
                                            <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                    d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                            </svg>
                                            <?php echo e($this->calculateDuration($pendidikan->tanggal_mulai, $pendidikan->tanggal_selesai)); ?>

                                        </div>
                                    <?php endif; ?>
                                </div>

                                <?php if($pendidikan->ipk): ?>
                                    <div class="flex items-center text-gray-500 text-sm mb-3">
                                        <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 24 24">
                                            <path d="M12 2l2.9 6.9 7.1.6-5.2 4.9 1.6 7.1L12 17.8 5.6 21.5l1.6-7.1L2 9.5l7.1-.6L12 2z" />
                                        </svg>

                                        IPK: <?php echo e($pendidikan->ipk); ?>

                                    </div>
                                <?php endif; ?>

                                <?php if($pendidikan->deskripsi): ?>
                                    <div class="prose prose-sm max-w-none text-gray-700">
                                        <p><?php echo e($pendidikan->deskripsi); ?></p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <!-- Empty State -->
        <?php endif; ?>
    </div>
</section><?php /**PATH D:\laragon\www\luna\resources\views\livewire\profile\update-pendidikan.blade.php ENDPATH**/ ?>