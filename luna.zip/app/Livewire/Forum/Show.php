<?php

namespace App\Livewire\Forum;

use Livewire\Component;

class Show extends Component
{
    public function render()
    {
        return view('livewire.forum.show');
    }
}
