<?php

namespace App\Livewire\Forum;

use Livewire\Component;

class Edit extends Component
{
    public function render()
    {
        return view('livewire.forum.edit');
    }
}
